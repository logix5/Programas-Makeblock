/**
* @file     MrtDuino.h
* @version  v0.5.0
* @date     2017.08.04
* @details  MRT DUINO 보드 관련 설정값 정의
*/
#ifndef MrtDuino_h
#define MrtDuino_h

#include <Arduino.h>
#include <pins_arduino.h>
#define  MRT_DUINO
#include <Wire.h>
#include "MrtCommon.h"

#include "MrtButton.h"
#include "MrtBuzzer.h"
#include "MrtDigitalOutput.h"
#include "MrtDigitalPWM.h"
#include "MrtDigitalInput.h"
#include "MrtAnalogInput.h"
#include "MrtMic.h"
#include "MrtGyro.h"
#include "MrtLsmMicro.h"
#include "LiquidCrystal_I2C.h"

#include "IRremote.h"
#include "MrtIdSetting.h"

#include "MrtMotor.h"
#include "MrtServo.h"
#include "ultrasonicWave.h"
#include "MrtRgbLed.h"
#include "MrtColor.h"
#include "SoftPWM.h"

#define PRESSED 1  // push button
#define RELEASED 0
#define SENSED  		1 // all the other Sensor sensed
#define NOSENSED  		0 // not sensed
#define LIGHT  		1
#define DARK  		0
#define INRANGE  		1  //ultra sensor
#define OUTOFRANGE 		0

// This is for checking ID selector and start button analoginput value.
#define ID00 1023  // Analog value of 00 all off stage
#define ID01 844   // Analog value of 01  stage
#define ID10 681   // Analog value of 10  stage
#define ID11 596   // Analog value of 11  stage
#define ST00 1023  // Analog value of 00 all off stage (ID button)
#define ST01 844   // Analog value of 01  stage (Start button)
#define ST10 681   // Analog value of 10  stage (ID button) 749~772
#define ST11 596   // Analog value of 11  stage (Start button/ ID button) 536~656(632)


#define TOLERANCE(v,p) (p/100.0)*v
#define STARTON (analogRead(23)>=(ST01 - TOLERANCE(ST01,6)) && analogRead(23)<=(ST01 + TOLERANCE(ST01,6)))\
 || (analogRead(23)>=(ST11 - TOLERANCE(ST11,6)) && analogRead(23)<=(ST11 + TOLERANCE(ST11,6)))
#define STARTOFF (analogRead(23)>=(ST00 - TOLERANCE(ST00,6)) && analogRead(23)<=(ST00 + TOLERANCE(ST00,6)))\
 || (analogRead(23)>=(ST10 - TOLERANCE(ST10,6)) && analogRead(23)<=(ST10 + TOLERANCE(ST10,6)))

#define ID3ON (analogRead(23)>=(ST10 - TOLERANCE(ST10,6)) && analogRead(23)<=(ST10 + TOLERANCE(ST10,6)))\
 || (analogRead(23)>=(ST11 - TOLERANCE(ST11,6)) && analogRead(23)<=(ST11 + TOLERANCE(ST11,6)))
#define ID2ON (analogRead(22)>=(ID01 - TOLERANCE(ID01,6)) && analogRead(22)<=(ID01 + TOLERANCE(ID01,6)))\
 || (analogRead(22)>=(ID11 - TOLERANCE(ID11,6)) && analogRead(22)<=(ID11 + TOLERANCE(ID11,6)))
#define ID1ON (analogRead(22)>=(ID10 - TOLERANCE(ID10,6)) && analogRead(22)<=(ID10 + TOLERANCE(ID10,6)))\
 || (analogRead(22)>=(ID11 - TOLERANCE(ID11,6)) && analogRead(22)<=(ID11 + TOLERANCE(ID11,6)))
#define IDOFF (analogRead(22)>=(ID00 - TOLERANCE(ID00,6)) && analogRead(22)<=(ID00 + TOLERANCE(ID00,6)))
#define STOFF (analogRead(23)>=(ST00 - TOLERANCE(ST00,6)) && analogRead(23)<=(ST00 + TOLERANCE(ST00,6)))
#define ID3OFF STOFF || (analogRead(23)>=(ST01 - TOLERANCE(ST01,6)) && analogRead(23)<=(ST01 + TOLERANCE(ST01,6)))

#define STOP_DIRECTION 0
#define FORWARD_DIRECTION 1
#define BACKWARD_DIRECTION 2
// define Mrt board pins, in/out pins are bi-directional.
#define INPUT1 (13)
#define INPUT2 (15)
#define INPUT3 (16)
#define INPUT4 (14)
#define INPUT5 (18)
#define INPUT6 (19)
#define INPUT7 (20)
#define INPUT8 (21)
#define OUTPUT1 (5)
#define OUTPUT2 (9)
#define OUTPUT3 (11)
#define OUTPUT4 (12)
#define OUTPUT5 (2) // RightFront Motor, when motor is using, this pin can be used
#define OUTPUT6 (3) // LeftFront Motor, when motor is using, this pin can be used
#define OUTPUT7 (0) // RightRear Motor, when motor is using, this pin can be used
#define OUTPUT8 (1) // LeftRear Motor, when motor is using, this pin can be used
#define IR_RECEIVER           (10)  //MRT Fixed port
#define ID_SETTING_PORT_1     (22)  //MRT Fixed port
#define ID_SETTING_PORT_2     (23)  //MRT Fixed port
// Port define

#define LED  	(13)
#define LEFTFRONT_MOTOR   3,7,0 // PWM
#define RIGHTFRONT_MOTOR  2,4,0 // PWM
#define LEFTREAR_MOTOR	  1,8,0 // PWM
#define RIGHTREAR_MOTOR   0,6,0 // PWM
#define LEFTFRONT_MOTOR_NOPWM   3,7 // No PWM
#define RIGHTFRONT_MOTOR_NOPWM  2,4  // No PWM
#define LEFTREAR_MOTOR_NOPWM	1,8  // No PWM
#define RIGHTREAR_MOTOR_NOPWM   0,6  // No PWM
#define M1 2,4
#define M2 0,6
#define M3 3,7
#define M4 1,8

#define NOCODE	73
#define F1	74 //J
#define F2	75 //K
#define F3	76 //L
#define F4	77 //M
#define F5	78 //N
#define F6	79 //O
#define UP	80 //P
#define DOWN	81 //Q
#define LEFT	82 //R
#define RIGHT	83 //S
#define UPDOWN	84 //T
#define LEFTRIGHT 85 //U
#define UPRIGHT	86 //V
#define DOWNLEFT 87 //W
#define UPLEFT	88 //X
#define DOWNRIGHT	89 //Y

#define ledon()  pinMode(LED,OUTPUT),digitalWrite(LED, HIGH)
#define ledoff() pinMode(LED,OUTPUT),digitalWrite(LED, LOW)
#define ledblink() pinMode(LED,OUTPUT),digitalWrite(LED,HIGH),delay(250),digitalWrite(LED, LOW),delay(250)

; //DON'T remove it
typedef unsigned char	uint8_t;
typedef unsigned int	uint16_t;
typedef unsigned long	uint32_t;
//typedef void (*myfun)();

#endif // MRTDuino_h

