/**
* @file     MrtButton.h
* @version  v0.4.0
* @date     2017.04.27
*
*/
#include "MrtCommon.h"

#ifndef MRT_BUTTON_H
#define MRT_BUTTON_H

#define BTN_SENSOR_PRESSED      LOW
#define BTN_SENSOR_RELEASED     HIGH

class MrtButton {
public:
    MrtButton();

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t btnPortNo  : 포트번호
     *
     */
    MrtButton(int8_t btnPortNo);

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t btnPortNo  : 포트번호
     *
     */
    void initButton(int8_t btnPortNo);

    /**
     * @brief  버튼이 눌려졌는지 체크
     *
     * @param    bool   flag   : 눌림(1)/해제(0) 여부
     * @return   bool   ret    : flag값이 일치하는지 여부
     *
     */
    bool      isPressed(bool flag);

    /**
     * @brief  버튼이 눌려졌는지 체크, 카운터
     *
     * @param    uint8_t    flag    눌림(1)/해제(0) 여부
     * @param    uint8_t    cnt     감지 횟수
     * @param    uint8_t    time    감지 시간
     * @return   bool       ret     flag값이 일치하는지 여부
     *
     */
    bool isPressed(uint8_t flag, uint8_t cnt, uint8_t time);

    /**
     * @brief  센서 값 읽기
     *
     * @return   int8_t val  : 센서값
     *
     */
    int8_t      btnRead();
private:
    int8_t  _buttonPinNo=-1;
};

#endif // MRT_BUTTON_H
