/**
  @file        MrtButton.cpp
  @version     v1.0.6
  @date        2018.02.23
  @details     Button형 Touch Sensor 정의 \n
    io type : digital INPUT \n
    Pressed   => LOW \n
    Released  => HIGH
*/
#include "MrtButton.h"

MrtButton::MrtButton() {}

/**
   @brief  센서 초기화

   @param   uint8_t btnPortNo  : 포트번호

*/
MrtButton::MrtButton(int8_t btnPortNo) {
  initButton(btnPortNo);
}

/**
   @brief  센서 초기화

   @param   uint8_t btnPortNo  : 포트번호

*/
void MrtButton::initButton(int8_t btnPortNo)
{
  _buttonPinNo = convertPinNumberInt(btnPortNo);
  pinMode(_buttonPinNo, INPUT);
}

/**
   @brief  버튼이 눌려졌는지 체크

   @param    bool   flag   : 눌림(1)/해제(0) 여부
   @return   bool   ret    : flag값이 일치하는지 여부

*/
bool MrtButton::isPressed(bool flag) {
  int8_t val = BTN_SENSOR_RELEASED;

  val = btnRead();
  if (val == flag) return true;
  else            return false;
}

/**
   @brief  버튼이 눌려졌는지 체크, 카운터

   @param    uint8_t    flag    눌림(1)/해제(0) 여부
   @param    uint8_t    cnt     감지 횟수
   @param    uint8_t    time    감지 시간
   @return   bool       ret     flag값이 일치하는지 여부

*/
bool MrtButton::isPressed(uint8_t flag, uint8_t cnt, uint8_t time) {
  unsigned long startTime = millis();
  unsigned int times = time * 1000;

  int8_t  btnVal = 0;
  uint16_t detectCnt = 0;
  bool result = false;

  while (millis() - startTime <= times) {

    btnVal = btnRead();

    // button detected
    if (flag == btnVal) {
      delay(times / cnt);
      detectCnt++;
    }

    if (detectCnt >= cnt) {
      result = true;
      break;
    }
  }

  return result;
}

/**
   @brief  센서 값 읽기

   @return   int8_t val  : 센서값

*/
int8_t MrtButton::btnRead()
{
  int8_t val;

  val = digitalRead(_buttonPinNo);
  return val;
}
