/**
* @file     MrtMic.cpp
* @author   keunja kim
* @version  v0.3.0
* @date     2016.12.29
* @details  MIC sensor
*/
#include "MrtMic.h"

MrtMic::MrtMic() {}

/**
 * @brief  마이크센서 초기화
 *
 * @param   uint8_t port_no    : 포트번호
 */
MrtMic::MrtMic(int8_t port_no) {
    initMic(port_no);
}

/**
 * @brief  마이크센서 초기화
 *
 * @param   uint8_t port_no    : 포트번호
 */
void MrtMic::initMic(int8_t port_no) {
    _pinNo = convertPinNumberInt(port_no);

    if (_pinNo >= 0) pinMode(_pinNo, INPUT_PULLUP); // pullup
}

/**
 * @brief   센서값 읽기
 *
 */
int MrtMic::readValue(void) {
    int val;

    val = analogRead(_pinNo);
    
    return val;
}

/**
 * @brief   read digital sensor
 *
 */
uint8_t MrtMic::readDigitalValue(void) {
    uint8_t val;
    val = digitalRead(_pinNo);
    return val;
}

/**
 * @brief   감지여부 체크, 1000 이하 감지
 *
 * @param   bool    flag        감지 여부, 감지(1)/미감지(0)
 * @param   int     threshold   감지여부 기준값, default = 1000
 * @return  bool    감지여부    (ANALOG_INPUT_SENSED/ANALOG_INPUT_NO_SENSED)
 *
 */
bool MrtMic::checkSensed(bool flag, int threshold) {
    int val = readValue();
    bool state = false;

    state = (val < threshold) ? ANALOG_INPUT_SENSED : ANALOG_INPUT_NO_SENSED;

    return (state == flag);
}

/**
 * @brief   check sensed as digital sensor
 *
 * @param   bool    flag        감지 여부, 감지(1)/미감지(0)
 */
bool MrtMic::checkDigitalSensed(bool flag) {
    uint8_t val = readDigitalValue();
    return (val != flag);
}

/**
 * @brief   check sensed as digital sensor, counter
 *
 * @param   bool        flag    감지 여부, 감지(1)/미감지(0)
 * @param   uint8_t     cnt     감지 횟수
 * @param   uint8_t     time    감지 시간
 * @return  bool        ret     flag값 체크 결과
 */
bool MrtMic::checkDigitalSensed(bool flag, uint8_t cnt, uint8_t time) {
    uint16_t delayTime = int((time * 1000) / cnt);

    uint8_t i = 0, readVal = 0;

    for (i=0; i<cnt; i++) {
        readVal += constrain(digitalRead(_pinNo), 0, 1);
        delay(delayTime);
    }

    bool result = false;
    // sensed, 0
    if (flag) {
        if (readVal == 0) result = true;
        else result = false;
    }
    // no sensed, 1
    else {
        if (readVal == cnt) result = true;
        else result = false;
    }

    return result;
}
