/**
* @file     MrtDigitalInput.h
* @version  v0.2.0
* @date     2016.09.26
* @details  일반적인 Digital Input 센서 처리 \n
*           Sensed    => HIGH \n
*           no-Sensed => LOW
*/
#include "MrtCommon.h"

#ifndef MRT_DIGITAL_INPUT_H
#define MRT_DIGITAL_INPUT_H

#define DIGITAL_INPUT_SENSED      HIGH
#define DIGITAL_INPUT_NO_SENSED   LOW

class MrtDigitalInput {
public:
    MrtDigitalInput();

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t port_no : 포트번호
     *
     */
    MrtDigitalInput(int8_t port_no);

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t port_no  : 포트번호
     *
     */
    void initDigitalInput(int8_t port_no);

    /**
     * @brief  센서값을 읽고,  감지 여부 확인
     *
     * @param    bool  flag  : 감지(1)/미감지(0) 여부 체크함.
     * @return   bool  ret   : flag값 체크 결과
     */
    bool    isSensed(bool flag);
    /**
     * @brief  센서값을 읽기
     *
     * @return   uint8_t  val : 센서값
     *
     */
    int8_t  readValue();

private:
    int8_t  _pinNo=-1;
    int     _delay_ms, _last_readtime;
};

#endif // MRT_DIGITAL_INPUT_H
