/**
 * @file     :   MrtRgbLed.cpp
 * @version  :   v0.5.0
 * @date     :   2017.08.14
 * @details  :   RGB Led 제어
 */
#include "MrtRgbLed.h"

// constructor
MrtRgbLed::MrtRgbLed() {}

/**
 * @brief       RGB Led 포트 초기화
 *
 * @param       int8_t red_port    : red 값 지정 포트
 * @param       int8_t green_port  : green 값 지정 포트
 * @param       int8_t blue_port   : blue 값 지정 포트
 */
MrtRgbLed::MrtRgbLed(int8_t red_port, int8_t green_port, int8_t blue_port) {
    initRgbLed(red_port, green_port, blue_port);
}

/**
 * @brief       RGB Led 포트 초기화
 *
 * @param       int8_t red_port    : red 값 지정 포트
 * @param       int8_t green_port  : green 값 지정 포트
 * @param       int8_t blue_port   : blue 값 지정 포트
 */
void MrtRgbLed::initRgbLed(int8_t red_port, int8_t green_port, int8_t blue_port)
{
    _redPin   = convertPinNumberInt(red_port);
    _greenPin = convertPinNumberInt(green_port);
    _bluePin  = convertPinNumberInt(blue_port);

    pinMode(_redPin,   OUTPUT);
    pinMode(_greenPin, OUTPUT);
    pinMode(_bluePin,  OUTPUT);
}

/**
 * @brief   initialize RGB Led with shield board
 *
 */
void MrtRgbLed::initRgbLed() {
    _redPin   = 9;
    _greenPin = 11;
    _bluePin  = 12;

    disableI2C(); // conflict with pin 9

    pinMode(_redPin, OUTPUT);
    pinMode(_greenPin, OUTPUT);
    pinMode(_bluePin, OUTPUT);

    SoftPWMBegin();
}

/**
 * @brief       색상 표시
 *
 * @param       uint8_t red    : red 값
 * @param       uint8_t green  : green 값
 * @param       uint8_t blue   : blue 값
 */
void MrtRgbLed::setColor(uint8_t red, uint8_t green, uint8_t blue)
{
    setColorAt(_redPin, red);
    setColorAt(_greenPin, green);
    setColorAt(_bluePin, blue);

    if( (red == 0) && (green == 0) && (blue == 0) )
    {
        SoftPWMEnd(_redPin);
        SoftPWMEnd(_greenPin);
        SoftPWMEnd(_bluePin);
    }

}

/**
 * @brief       개별 색상 표시
 *
 * @param       uint8_t pin
 * @param       uint8_t val color value (0-255)
 */
void MrtRgbLed::setColorAt(uint8_t pin, uint8_t val) {
    switch (pin) {
    case 11:
        analogWrite(pin, val);
        break;
    default:
        SoftPWMSet(pin, val);
        break;
    }//switch
}
