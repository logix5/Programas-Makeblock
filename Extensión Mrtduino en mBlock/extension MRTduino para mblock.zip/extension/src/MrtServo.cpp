/**
   @file     :   MrtServo.cpp
   @version  :   v0.5.0
   @date     :   2018.04.26
   @details  :   서보모터 속도값 계산 분모 0 입력 시 스크래치 다운 오류 수정
*/
#include "MrtServo.h"

volatile st_analogServo analogServo;

// constructor
MrtServo::MrtServo() {};

/**
   @brief  아날로그 서보 모터 초기화

   @param   int8_t         port_no    :  서보모터 포트번호

*/
void MrtServo::initServoMotor(int8_t port_no) {

  int8_t _motorPinNo = convertPinNumberInt(port_no);
  if (_motorPinNo < 0)     return;
  pinMode(_motorPinNo, OUTPUT);

  analogServo.index = port_no - 9;  // port9 ~ port12
  analogServo.data[analogServo.index].pinNo = _motorPinNo;

  if (!_servoEnable) servoEnable();
}

/**
   @brief  아날로그 서보 모터 초기화 (for pin)

   @param   uint8_t  servoPin   servo motor pin

*/
void MrtServo::initServoPin(uint8_t servoPin) {
  if (servoPin > 12) return ;

  pinMode(servoPin, OUTPUT);

  if (servoPin == 5) {
    analogServo.index = 0;
  }
  else if (servoPin == 9) {
    analogServo.index = 1;
  }
  else {
    analogServo.index = servoPin - 9;
  }

  //analogServo.index = servoPin;
  analogServo.data[analogServo.index].pinNo = servoPin;

  if (!_servoEnable) servoEnable();
}

/** @brief servo interrupt enable

*/
void MrtServo::servoEnable(void) {
  TCCR3A = 0;             // normal counting mode
  TCCR3B = _BV(CS31);     // set prescaler of 8
  TCNT3 = 0;              // clear the timer count

  TCNT3 = 31266;

  TIFR3  =  _BV(OCF3A);     // clear any pending interrupts;
  TIMSK3 =  _BV(TOIE3);     // enable overflow interrupts

  _servoEnable = true;
}

/** @brief servo interrupt disable

*/
void MrtServo::servoDisable(void) {
  TIMSK3 &=  ~_BV(TOIE3);
  TCCR3B = 0x00;
  _servoEnable = false;
}

/**
   @brief   서보모터 인터럽트 처리
*/
ISR(TIMER3_OVF_vect)
{
  // Send pulse only when update time(20 ms) has passed
  if (int(millis() - analogServo.data[analogServo.index].lastPulse) >= analogServo.data[analogServo.index].refreshTime)
  {
    digitalWrite(analogServo.data[analogServo.index].pinNo, HIGH);
    delayMicroseconds(analogServo.data[analogServo.index].pulseWidth);
    digitalWrite(analogServo.data[analogServo.index].pinNo, LOW);
    analogServo.data[analogServo.index].lastPulse = millis();           // save the time of the last pulse
  }
}

/**
   @brief   아날로그 서보모터 구동

   @param   int16_t         angle     :  각도 (-150 ~ 150)
   @param   uint8_t         speed     :  속도 (0, 25, 50, 75, 100)
*/
void MrtServo::runServoMotor(int16_t angle, uint8_t speed) {
  float   loop_cnt = 0;
  int16_t  tmp_angle = 0;
          
  int8_t index = analogServo.index;

  if (speed != 0) loop_cnt = 1000.0 / (speed / 3); // 확실한 속도차이를 위해 speed / 3 만큼 가중치 적용
  else loop_cnt = 0;

  for (int i = 1; i <= loop_cnt; i++)
  {
    if ( analogServo.data[index].preAngle > angle)
      tmp_angle = analogServo.data[index].preAngle - (analogServo.data[index].preAngle - angle) / loop_cnt * i;
    else
      tmp_angle = analogServo.data[index].preAngle + (angle - analogServo.data[index].preAngle) / loop_cnt * i; // -각도 조절을 위한 가중치
    // analogServo.data[index].pulseWidth = ( analogServo.data[index].minPulse + ((analogServo.data[index].maxPulse-analogServo.data[index].minPulse)/300.0 * (tmp_angle+150)));
    
    analogServo.data[index].pulseWidth = ( analogServo.data[index].minPulse + ((analogServo.data[index].maxPulse - analogServo.data[index].minPulse) / 300.0 * (tmp_angle + 150)));
    
    // 각도가 0보다 클 때와 작을 때 서로 다른 가중치 적용(테스트 후 가중치 선정)
    if(analogServo.data[index].pulseWidth >= 0) analogServo.data[index].pulseWidth = analogServo.data[index].pulseWidth * 1.1;
    else analogServo.data[index].pulseWidth = analogServo.data[index].pulseWidth * 0.4;
    delay(20);  // delay를 이용하여 속도제어
  }

  analogServo.data[index].preAngle = angle;
  
  delay(speed * 1.3);
}

/**
   @brief   아날로그 서보모터 구동

   @param   uint8_t         port_no    :  서보모터 포트번호
   @param   int16_t         angle     :  각도 (-150 ~ 150)
   @param   uint8_t         speed     :  속도 (0, 25, 50, 75, 100)
*/
void MrtServo::runServoMotor(uint8_t port_no, int16_t angle, uint8_t speed) {

  initServoMotor(port_no);    // initialize

  float   loop_cnt = 0;
  int16_t  tmp_angle = 0;

  int8_t index = analogServo.index;

  if (speed != 0) loop_cnt = 1000.0 / (speed / 3); // 확실한 속도차이를 위해 speed / 3 만큼 가중치 적용
  else loop_cnt = 0;

  for (int i = 1; i <= loop_cnt; i++) {
    if ( analogServo.data[index].preAngle > angle)
      tmp_angle = analogServo.data[index].preAngle - (analogServo.data[index].preAngle - angle) / loop_cnt * i;
    else
      tmp_angle = analogServo.data[index].preAngle + (angle - analogServo.data[index].preAngle) / loop_cnt * i;
   //analogServo.data[index].pulseWidth = ( analogServo.data[index].minPulse + ((analogServo.data[index].maxPulse - analogServo.data[index].minPulse) / 300.0 * (tmp_angle + 150))) ;
   analogServo.data[index].pulseWidth = ( analogServo.data[index].minPulse + ((analogServo.data[index].maxPulse - analogServo.data[index].minPulse) / 250.0 * (tmp_angle + 150)));
    delay(20);  // delay를 이용하여 속도제어
  }

  analogServo.data[index].preAngle = angle;
  delay(speed * 1.3);
}

/**
   @brief  서보모터 정지

*/
void MrtServo::stopServoMotor() {
  TIMSK3 &= ~_BV(TOIE3);

  _servoEnable = false;
}
