/**
 * @file     :   MrtCommon.cpp
 * @version  :   v0.3.0
 * @date     :   2017.07.25
 * @details 공통함수
 */
#ifndef MRT_COMMON_H
#define MRT_COMMON_H

#include <Arduino.h>

// check sensed analog sensor
#define ANALOG_INPUT_SENSED     1
#define ANALOG_INPUT_NO_SENSED  0

/**
 * @brief  Duino Port 번호를 프로그램에서 사용할 pin 번호로 변경
 * @param  int8_t   iopin     :  포트 번호 (input1 -> 1.. input8->8.. output1->9.. output8->16)
 * @return uint8_t  pinno     :  핀번호
 *    예) input1의 경우 1이 입력되면 13번 넘겨줌. \n
 *        input2의 경우 2      "     15  " \n
 *        .... \n
 *        17 ~ 20 dc 모터의 포트정의 \n
 *        (ML1:7,3   MR1:4,2 \n
 *         ML2:8,1   MR2:6,0)
 */
uint8_t convertPinNumberInt(int8_t iopin);

/** @brief disable I2C, gyro와 pwm 충돌
 *
 */
void disableI2C(void);

void enableI2C(void);

#endif // MRT_COMMON_H
