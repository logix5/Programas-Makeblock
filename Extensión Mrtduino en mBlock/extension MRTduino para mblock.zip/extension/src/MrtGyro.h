/**
* @file     MrtGyro.cpp
* @author   Jongsuk Lee
* @version  v0.3.0
* @date     2017.08.15
* @details  자이로 센서 (GY-521 모듈)
*/
#ifndef MRT_GYRO_H
#define MRT_GYRO_H

#define MPU6050_I2C_ADDRESS 0x68  // MPU 6050 의 I2C 기본 주소
// address pin low (GND), default for InvenSense evaluation board
# define MPU6050_RA_WHO_AM_I         0x75

// 1000ms default read timeout (modify with "I2Cdev::readTimeout = [ms];")
# define I2CDEV_DEFAULT_READ_TIMEOUT     1000

#define PWR_MGMT_1          0x6B  // PWR_MGMT_1 register의 주소
#define GYRO_CONFIG_REG     0x1B  // gyro config register, full-scale range +/- 250 degrees/sec, 500, 1000, 2000
#define ACCEL_CONFIG_REG    0x1C  // accel config register, full-scale range +/- 2g, 4g, 8g, 16g
#define ACCEL_XOUT_H        0x3B

# define MPU6050_WHO_AM_I_BIT        6
# define MPU6050_WHO_AM_I_LENGTH     6

#define SWAP(x,y) tmp = x; x = y; y = tmp

#define USE_KALMAN_FILTER

/* 자이로 센서값 저장 structure */
typedef union accel_t_gyro_union {
    struct {
        uint8_t x_accel_h;
        uint8_t x_accel_l;
        uint8_t y_accel_h;
        uint8_t y_accel_l;
        uint8_t z_accel_h;
        uint8_t z_accel_l;
        uint8_t t_h;
        uint8_t t_l;
        uint8_t x_gyro_h;
        uint8_t x_gyro_l;
        uint8_t y_gyro_h;
        uint8_t y_gyro_l;
        uint8_t z_gyro_h;
        uint8_t z_gyro_l;
    } reg;

    struct {
        int x_accel;
        int y_accel;
        int z_accel;
        int temperature;
        int x_gyro;
        int y_gyro;
        int z_gyro;
    } value;
};

#if defined(USE_KALMAN_FILTER)  // use kalman_filter
/* Kalman filter */
struct GyroKalman{
	/* These variables represent our state matrix x */
	float x_angle, x_bias;

	/* Our error covariance matrix */
	float P_00, P_01, P_10, P_11;

	/*
	* Q is a 2x2 matrix of the covariance. Because we
	* assume the gyro and accelerometer noise to be independent
	* of each other, the covariances on the / diagonal are 0.
	* Covariance Q, the process noise, from the assumption
	* x = F x + B u + w
	* with w having a normal distribution with covariance Q.
	* (covariance = E[ (X - E[X])*(X - E[X])' ]
	* We assume is linear with dt
	*/
	float Q_angle, Q_gyro;

	/*
	* Covariance R, our observation noise (from the accelerometer)
	* Also assumed to be linear with dt
	*/
	float R_angle;
};


/*
* R represents the measurement covariance noise. In this case,
* it is a 1x1 matrix that says that we expect 0.3 rad jitter
* from the accelerometer.
*/
static const float R_angle = 0.3; 		//.3 default

/*
* Q is a 2x2 matrix that represents the process covariance noise.
* In this case, it indicates how much we trust the acceleromter
* relative to the gyros
*/
static const float Q_angle = 0.01;	//0.01 (Kalman)
static const float Q_gyro = 0.04;	//0.04 (Kalman)

//These are the limits of the values I got out of the Nunchuk accelerometers (yours may vary).
const int lowX = -2150;
const int highX = 2210;
const int lowY = -2150;
const int highY = 2210;
const int lowZ = -2150;
const int highZ = 2550;

#endif

/* defined in MrtGyro.cpp */
extern volatile accel_t_gyro_union accel_t_gyro;


class MrtGyro {
public:
    
    /**
     * @brief  센서 초기화
     */
    void    initGyro();

    /**
     * @brief  센서 값 읽기
     */
    void    readData();
    /**
     * @brief  MPU6050_read로 읽은 값을 accel_t_gyro.value... 으로 사용하고자 할때 high, low bit 바꿔줌
     *
     */
    void    MrtSwap();

    /**
    * @brief  MPU6050에서 데이터 읽기
    *
    * @param  int      start    읽을 위치
    *         uint8_t  *buffer  읽은 내용 저장할 버퍼
    *         int      size     읽을 크기
    * @return int      n        0 : 정상적으로 읽은 경우
    */
    int     MPU6050_read(int start, uint8_t *buffer, int size);
    /**
     * @brief  MPU6050에 데이터 쓰기
     *
     * @param  int      start    기록할 위치
     *         uint8_t  *buffer  기록할 내용 저장된 버퍼
     *         int      size     기록할 크기
     * @return int      n        0 : 정상적으로 기록된 경우
     */
    int     MPU6050_write(int start, const uint8_t *pData, int size);
    int     MPU6050_write_reg(int reg, uint8_t data);

    /**
     * @brief  gyro 특정 축 값 읽기
     * @param  uint8_t  xyz_flag  gyro 축 (0:x축, 1:y축, 2:z축)
     * @return int      value
     */
    int getAxisValue(uint8_t xyz_flag);

    /**
     * @brief  gyro 특정 축 값 읽기
     * @param  uint8_t  xyz_flag  gyro 축 (0:x축, 1:y축, 2:z축)
     * @return int      value
     */
    int getAxisAt(uint8_t xyz_flag);

    

#if defined(USE_KALMAN_FILTER) // use kalman_filter
    /**
     * @brief  칼만필터 적용해서 보정된 값을 추출
     *
     * @param  int *_gx1  보정 후 x축 값
     *         int *_gy1  보정 후 y축 값
     *         int *_gz1  보정 후 z축 값
     */
    void    Kalman_filter(int *_gx1, int *_gy1, int *_gz1);
    float   angleInDegrees(int lo, int hi, int measured);
    void    initGyroKalman(struct GyroKalman *kalman, const float Q_angle, const float Q_gyro, const float R_angle);
    void    predict(struct GyroKalman *kalman, float dotAngle, float dt);
    float   update(struct GyroKalman *kalman, float angle_m);
#endif

private:
    uint8_t buffer[14];
    bool _isStart = true;

    /* time */
#if defined(USE_KALMAN_FILTER) // use kalman_filter
    unsigned long prevSensoredTime = 0;
    unsigned long curSensoredTime = 0;
    int xInit[5] = {0,0,0,0,0};
    int yInit[5] = {0,0,0,0,0};
    int zInit[5] = {0,0,0,0,0};
    int initIndex = 0;
    int initSize = 5;
    int xCal = 0;
    int yCal = 0;
    int zCal = 1800;

    struct GyroKalman angX;
    struct GyroKalman angY;
    struct GyroKalman angZ;
#endif

};
#endif // MRT_GYRO_H
