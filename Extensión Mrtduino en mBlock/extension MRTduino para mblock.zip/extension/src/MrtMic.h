/**
* @file     MrtMic.h
* @author   keunja kim
* @version  v0.3.0
* @date     2016.12.29
* @details  MIC sensor
*/
#ifndef MRT_MIC_H_
#define MRT_MIC_H_

#include "MrtCommon.h"

class MrtMic {
public:
    MrtMic();

    /**
     * @brief  마이크센서 초기화
     *
     * @param   uint8_t port_no    : 포트번호
     */
    MrtMic(int8_t port_no);

    /**
     * @brief  마이크센서 초기화
     *
     * @param   uint8_t port_no    : 포트번호
     */
    void initMic(int8_t port_no);

    /**
     * @brief   센서값 읽기
     *
     */
    int readValue(void);

    /**
     * @brief   read digital sensor
     *
     */
    uint8_t readDigitalValue(void);

    /**
     * @brief   감지여부 체크, 1000 이하 감지
     *
     * @param   bool    flag        감지 여부, 감지(1)/미감지(0)
     * @param   int     threshold   감지여부 기준값, default = 1000
     * @return  bool    감지여부    (ANALOG_INPUT_SENSED/ANALOG_INPUT_NO_SENSED)
     *
     */
    bool checkSensed(bool flag, int threshold=1000);

    /**
     * @brief   check sensed as digital sensor
     *
     * @param   bool    flag        감지 여부, 감지(1)/미감지(0)
     */
    bool checkDigitalSensed(bool flag);

    /**
     * @brief   check sensed as digital sensor, counter
     *
     * @param   bool        flag    감지 여부, 감지(1)/미감지(0)
     * @param   uint8_t     cnt     감지 횟수
     * @param   uint8_t     time    감지 시간
     * @return  bool        ret     flag값 체크 결과
     */
    bool checkDigitalSensed(bool flag, uint8_t cnt, uint8_t time);

private:
    int8_t _pinNo;      ///< pin number
};
#endif // MRT_MIC_H_
