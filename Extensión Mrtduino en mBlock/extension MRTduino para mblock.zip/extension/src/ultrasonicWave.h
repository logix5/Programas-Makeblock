/**
 * @file     ultrasonicWave.h
 * @version  v0.4.1
 * @date     2017.04.10
 * @details  초음파센서 거리측정 모듈
 */

#ifndef ULTRASONIC_WAVE_H
#define ULTRASONIC_WAVE_H
#include <Arduino.h>
#include "SoftPWM.h"
#include "MrtCommon.h"

class ultrasonicWave {
public:
    ultrasonicWave();

    /**
     * @brief       초음파센서 포트 초기화
     *
     * @param       int8_t trig_port   : trig 포트
     * @param       int8_t echo_port   : echo 포트
     */
    ultrasonicWave(int8_t trig_port, int8_t echo_port);

    /**
     * @brief       초음파센서 포트 초기화
     *
     * @param       int8_t trig_port   : trig 포트
     * @param       int8_t echo_port   : echo 포트
     */
    void initUltrasonic(int8_t trig_port, int8_t echo_port);

    /**
     * @brief       초음파센서 포트 초기화 (for pin)
     *
     * @param       int trigPin   : trig pin
     * @param       int echoPin   : echo pin
     */
    void initUltrasonicPin(int trigPin, int echoPin);

    /**
     * @brief       초음파센서 포트 초기화, shield board
     *
     */
    void initUltrasonic(void);

    /**
     * @brief       거리 측정
     *
     * @return      long distance  : 측정된 거리 값( cm )
     */
    long checkDistance(void);

    /**
     * @brief       거리 측정, shield board
     *
     * @return      long distance  : 측정된 거리 값( cm )
     */
    float getDistance(void);

private:
    int8_t  _trigPin = -1;
    int8_t  _echoPin = -1;
};

#endif // ULTRASONIC_WAVE_H

