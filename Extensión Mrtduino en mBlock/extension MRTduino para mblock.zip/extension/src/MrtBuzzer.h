/**
 * @file     MrtBuzzer.h
 * @author   Jongsuk Lee
 * @version  v0.3.0
 * @date     2017.01.06
 *
 */
#include "MrtCommon.h"
#include "SoftPWM.h"

#ifndef MRT_BUZZER_H
#define MRT_BUZZER_H

#define MRT_BUZZER_ON   HIGH
#define MRT_BUZZER_OFF  LOW

class MrtBuzzer {
public:
    MrtBuzzer();

    /**
     * @brief  센서 초기화
     *
     * @param   int8_t  port_no   : 포트번호
     *
     */
    MrtBuzzer(int8_t port_no);

    /**
     * @brief  센서 초기화
     *
     * @param   int8_t  port_no   : 포트번호
     *
     */
    void initBuzzer(int8_t port_no);
    /**
     * @brief   Buzzer 켜기
     */
    void buzzerOn();
    /**
     * @brief   Buzzer 끄기
     */
    void buzzerOff();
    /**
     * @brief   Buzzer ON/OFF
     *
     * @param   int flag    : on(1)/off(0) 스위치
     */
    void runBuzzer(int flag);

    /**
     * @brief   play buzzer, speaker
     *
     * @param   unsigned int    frequency  : 출력 주파수 in hertz
     * @param   unsigned long   duration   : 지속시간 in milliseconds
     *
     */
    void tone2(unsigned int frequency, unsigned long duration);

    /**
     * @brief   지정된 주파수를 가진 구형파(square wave) 출력 \n
     *          duty cycle 50% \n
     *          예를들면, 도는 digital on/off를 261번 해야한다. 이때 frequency가 261이 된다.
     *
     * @param   unsigned int    frequency  : 출력 주파수 in hertz
     *          unsigned long   duration   : 지속시간 in milliseconds
     *
     */
    int  buzzerTone(unsigned int frequency, unsigned long duration);

    /**
     * @brief   지정된 주파수를 가진 구형파(square wave) 출력 \n
     *          duty cycle 50% \n
     *          예를들면, 도는 digital on/off를 261번 해야한다. 이때 frequency가 261이 된다.
     *
     * @param   uint16_t    frequency  : 출력 주파수 in hertz
     * @param   uint16_t   duration   : 지속시간 in milliseconds
     *
     */
    int buzzerTone2(uint16_t frequency, uint16_t duration);

private:
    int8_t      _pinNo;
};

#endif // MRT_BUZZER_H

