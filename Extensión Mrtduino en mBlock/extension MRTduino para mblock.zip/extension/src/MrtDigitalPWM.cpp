/**
  @file     MrtDigitalPWM.cpp
  @version  v1.0.6
  @date     2018.02.23
  @details  일반적인 Digital PWM 처리 \n
*/
#include "MrtDigitalPWM.h"

MrtDigitalPWM::MrtDigitalPWM() {};

MrtDigitalPWM::MrtDigitalPWM(int8_t port_no)
{
  initDigitalPWM(port_no);
}

void MrtDigitalPWM::initDigitalPWM(int8_t port_no)
{
  if ((port_no == 13) || (port_no == 14)) disableI2C();

  _pinNo = convertPinNumberInt(port_no);
  pinMode(_pinNo, OUTPUT);
}

void MrtDigitalPWM::runPWM(int8_t pwm)
{
  analogWrite(_pinNo, pwm);
}

