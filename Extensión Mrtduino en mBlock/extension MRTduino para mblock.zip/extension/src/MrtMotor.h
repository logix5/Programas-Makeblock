/*
   @file     MrtMotor.h
   @version  v1.0.6
   @date     2018.02.23
*/

#ifndef MRT_MOTOR_H
#define MRT_MOTOR_H

#include <Arduino.h>
#include "SoftPWM.h"
#include "MrtCommon.h"

class MrtMotor {
  public:
    MrtMotor();

    /*
        @brief finish soft pwm
    */
    void endMotor(void);

    /*
       @brief  DC Motor driven
       @param  int8_t  speed : speed (-100~100)
    */
    void runMotor(int8_t speed);

    /*
       @brief  run DC motor
       @param   uint8_t port  port number (1: ML1, 2: MR1, 3: ML2, 4: MR2)
       @param   int speed (-255 ~ 255)
    */
    void runMotor(uint8_t port, int speed);

    /*
       @brief  Motor stop
    */
    void stopMotor();

  private:
    int8_t _motorPinNo = -1;        // connected pin number with motor
    int8_t _directionPinNo = -1;    // pin number for direction control (forward/back)
};

#endif // MRT_MOTOR_H
