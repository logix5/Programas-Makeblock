/**
 * @file    :   MRTduinoExtension.js
 * @version :   1.0.7
 * @date    :   2018.04.26
 * @details :   
 */
(function(ext) {
    var device = null;
    var _rxBuf = [];

    // device id
    var devices = {
        "TouchSensor": 1,
        "InfraredSensor": 2,
        "CdsSensor": 3,
        "MicSensor": 4,
        "BalanceSensor": 5,
        "VibrationSensor": 6,
        "MagneticSensor": 7,
        "FlameSensor": 8,
        "Custom":9,
        "Motor": 10,
        "Servo": 11,
        "LED": 12,
        //"RGBled": 13,
        "Buzzer": 14,
        "IRremote": 15,
        //"UltrasonicSensor": 16,
        //"GyroSensor": 17,
        "Speaker": 18,
        //"StartButton": 19, // not used
        "Potentiometer": 20,
        //"ColorSensor": 21, // not used
        "CustomPWM": 24,
        "Digital": 30,
        "Analog": 31,
        "PWM": 32
        
    };
    
    /// ports
    //var ports = {"Port1": 1, "Port2": 2, "Port3": 3, "Port4": 4, "Port5": 5, "Port6": 6, "Port7": 7, "Port8": 8, "Port9": 9, "Port10": 10, "Port11": 11, "Port12": 12, "Port13": 13, "Port14": 14, "Port15": 15, "Port16": 16, "ML1": 17, "MR1": 18, "ML2": 19, "MR2": 20};
    var ports = {"Port1": 1, "Port2": 2, "Port3": 3, "Port4": 4, "Port5": 5, "Port6": 6, "Port7": 7, "Port8": 8, "Port9": 9, "Port10": 10, "Port11": 11, "Port12": 12, "Port13": 13, "Port14": 14, "Port15": 15, "Port16": 16, "ML1": 1, "MR1": 2, "ML2": 3, "MR2": 4};
    
    var states = {"pressed": 1, "released": 0, "sense": 1, "none": 0, "sensed": 0, "nosensed": 1};
    
    var outputValues = {"HIGH": 1, "LOW": 0};
    var onOffValues = {"On":1, "Off":0};
    var opValues = {">=": 1, ">": 2, "=": 3, "<": 4, "<=": 5};
    //var irButtonValues = {"up arrow": 44, "down arrow": 62, "left arrow": 63, "right arrow": 61, "up-left arrow": 54, "up-right arrow": 60, "down-left arrow": 51, "down-right arrow": 57, "F1": 50, "F2": 35, "F3": 52, "F4": 37, "F5": 38, "F6": 55};
    var irButtonValues = {"Release": 53, "up": 44, "down": 62, "left": 63, "right": 61, "up-left": 54, "up-right": 60, "down-left": 51, "down-right": 57, "F1": 50, "F2": 35, "F3": 52, "F4": 37, "F5": 38, "F6": 55};
    //var axisValues = {"X-axis": 0, "Y-axis": 1, "Z-axis": 2};
    
    /*var tones ={"C2":65,"D2":73,"E2":82,"F2":87,"G2":98,"A2":110,"B2":123,
    "C3":131,"D3":147,"E3":165,"F3":175,"G3":196,"A3":220,"B3":247,
    "C4":262,"D4":294,"E4":330,"F 4":349,"G4":392,"A4":440,"B4":494,
    "C5":523,"D5":587,"E5":659,"F5":698,"G5":784,"A5":880,"B5":988,
    "C6":1047,"D6":1175,"E6":1319,"F6":1397,"G6":1568,"A6":1760,"B6":1976,
    "C7":2093,"D7":2349,"E7":2637,"F7":2794,"G7":3136,"A7":3520,"B7":3951,
    "C8":4186,"D8":4699}; */
     var tones ={"NOTE_C2": 65, "NOTE_D2": 73, "NOTE_E2": 82, "NOTE_F2": 87, "NOTE_G2": 98, "NOTE_A2": 110, "NOTE_B2": 123, "NOTE_C3": 131, "NOTE_D3": 147, "NOTE_E3": 165, "NOTE_F3": 175, "NOTE_G3": 196, "NOTE_A3": 220, "NOTE_B3": 247, "NOTE_C4": 262, "NOTE_D4": 294, "NOTE_E4": 330, "NOTE_F4": 349, "NOTE_G4": 392, "NOTE_A4": 440, "NOTE_B4": 494, "NOTE_C5": 523, "NOTE_D5": 587, "NOTE_E5": 659, "NOTE_F5": 698, "NOTE_G5": 784, "NOTE_A5": 880, "NOTE_B5": 988, "NOTE_C6": 1047, "NOTE_D6": 1175, "NOTE_E6": 1319, "NOTE_F6": 1397, "NOTE_G6": 1568, "NOTE_A6": 1760, "NOTE_B6": 1976, "NOTE_C7": 2093, "NOTE_D7": 2349, "NOTE_E7": 2637, "NOTE_F7": 2794, "NOTE_G7": 3136, "NOTE_A7": 3520, "NOTE_B7": 3951, "NOTE_C8": 4186, "NOTE_D8": 4699};
    
    var beats = {"Half": 500,"Quater": 250,"Eighth": 125,"Whole": 1000, "Double": 2000, "Zero": 0};
    
    var values = {};
    var nextID = 0;
    
    ext.resetAll = function() {
        device.send([0xff, 0x55, 2, 0, 4]);
    };

    // coconut Program
    ext.runArduino = function() {};

    /// touch sensor
    /**
     * @brief   read touch sensor value
     *
     * @param   port        input ports (port1~8)
     */
    ext.getTouch = function (nextID, port) {
        if (typeof port == "string") port = ports[port];
        getPackage(nextID, devices["TouchSensor"], port);
    };
    
    /**
     * @brief   터치센서, 누름/해제
     *
     * @param   port        input ports (port1~8)
     * @param   touchValue  누름/해제
     */
    ext.runTouch = function(nextID, port, touchValue) {
        if (typeof port == "string") port = ports[port];
        if (typeof touchValue == "string") touchValue = states[touchValue];
        
        getPackage(nextID, devices["TouchSensor"], port, touchValue);
    };
    
    /**
     * @brief   터치센서, 누름/해제
     *
     * @param   port        input ports (port1~8)
     * @param   touchValue  누름/해제
     * @param   count       감지횟수
     * @param   time        감지시간
     */
    ext.runTouchCount = function(nextID, port, touchValue, count, time) {
        if (typeof port == "string") port = ports[port];
        if (typeof touchValue == "string") touchValue = states[touchValue];
        
        getPackage(nextID, devices["TouchSensor"], port, touchValue, count, time);
    };
    
    /// infrared sensor
    /**
     * @brief   read infrared sensor value 
     *
     * @param   port        input ports (port5~8)
     */
    ext.getInfrared = function(nextID, port) {
        if (typeof port == "string") port = ports[port];
        getPackage(nextID, devices["InfraredSensor"], port);
    };
    
    /**
     * @brief   적외선센서 감지/미감지
     *
     * @param   port        input ports
     * @param   senseValue  누름/해제
     */
    ext.runInfrared = function(nextID, port, senseValue) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["InfraredSensor"], port, senseValue);
    };
    
    /**
     * @brief   적외선센서 감지/미감지, count
     *
     * @param   port        input ports
     * @param   senseValue  누름/해제
     * @param   count       감지횟수
     * @param   time        감지시간
     */
    ext.runInfraredCount = function(nextID, port, senseValue, count, time) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["InfraredSensor"], port, senseValue, count, time);
    };
    
    /// cds sensor
    /**
     * @brief   Cds센서 측정
     *
     * @param   port        input ports (port5~8)
     */
    ext.getLight = function(nextID, port) {
        if (typeof port == "string") port = ports[port];
                
        getPackage(nextID, devices["CdsSensor"], port);
    };
    
    /**
     * @brief   Cds센서 감지/미감지
     *
     * @param   port        input ports
     * @param   senseValue  sensed, nosensed
     */
    ext.runLight = function(nextID, port, senseValue) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["CdsSensor"], port, senseValue);
    };
    
    /// MIC sensor
    /**
     * @brief   Mic sensor 측정
     *
     * @param   port        input ports (port 1-8)
     */
    ext.getMic = function(nextID, port) {
        if (typeof port == "string") port = ports[port];
        getPackage(nextID, devices["MicSensor"], port);
    };
    
    /**
     * @brief   MIC sensor 감지/미감지
     *
     * @param   port        input ports
     * @param   senseValue  누름/해제
     */
    ext.runMic = function(nextID, port, senseValue) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["MicSensor"], port, senseValue);
    };
    
    /**
     * @brief   MIC sensor 감지/미감지
     *
     * @param   port        input ports
     * @param   senseValue  누름/해제
     * @param   count       감지횟수
     * @param   time        감지시간
     */
    ext.runMicCount = function(nextID, port, senseValue, count, time) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["MicSensor"], port, senseValue, count, time);
    };
    
    /// Balance sensor
    /**
     * @brief   Balance 센서 측정
     *
     * @param   port        input ports (port1~8)
     */
    ext.getBalance = function(nextID, port) {
        if (typeof port == "string") port = ports[port];
        getPackage(nextID, devices["BalanceSensor"], port);
    };
    
    /**
     * @brief   Balance 센서 감지/미감지
     *
     * @param   port        input ports
     * @param   senseValue  감지/미감지
     */
    ext.runBalance = function(nextID, port, senseValue) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["BalanceSensor"], port, senseValue);
    };
    
    /// vibration sensor
    /**
     * @brief   read vibration sensor value
     *
     * @param   port        input ports (port5-8)
     */
    ext.getVibration = function(nextID, port) {
        if (typeof port == "string") port = ports[port];
        getPackage(nextID, devices["VibrationSensor"], port);
    };
    
    /**
     * @brief   진동센서 감지/미감지
     *
     * @param   port        input ports (port 5-8)
     * @param   senseValue  감지/미감지
     */
    ext.runVibration = function(nextID, port, senseValue) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["VibrationSensor"], port, senseValue);
    };
    
    /**
     * @brief   진동센서 감지/미감지
     *
     * @param   port        input ports (port 5-8)
     * @param   senseValue  감지/미감지
     * @param   count       감지횟수
     * @param   time        감지시간
     */
    ext.runVibrationCount = function(nextID, port, senseValue, count, time) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["VibrationSensor"], port, senseValue, count, time);
    };
    
    /// magnetic sensor
    /**
     * @brief   read magnetic sensor value 
     *
     * @param   port        input ports (port 1-8)
     */
    ext.getMagnetic = function(nextID, port) {
        if (typeof port == "string") port = ports[port];
        
        getPackage(nextID, devices["MagneticSensor"], port);
    };
    
    /**
     * @brief   자석센서 감지/미감지
     *
     * @param   port        input ports (port 1~8)
     * @param   senseValue  감지/미감지
     */
    ext.runMagnetic = function(nextID, port, senseValue) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["MagneticSensor"], port, senseValue);
    };
    
    /**
     * @brief   read flame sensor value
     *
     * @param   port        input ports (port5-8)
     */
    ext.getFlame = function(nextID, port) {
        if (typeof port == "string") port = ports[port];
        
        getPackage(nextID, devices["FlameSensor"], port);
    };
    
    /**
     * @brief   불꽃센서 감지/미감지
     *
     * @param   port        input ports (port5-8)
     * @param   senseValue  감지/미감지
     */
    ext.runFlame = function(nextID, port, senseValue) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        
        getPackage(nextID, devices["FlameSensor"], port, senseValue);
    };
    
    /**
     * @brief   check ir receiver pressed 
     *
     * @param   buttonValue up:12, down:14, left:15, right: 13, F1, F2, F3, F4, F5, F6
     */
    ext.getIRremote = function(nextID, buttonValue) {
        if (typeof buttonValue == "string") buttonValue = irButtonValues[buttonValue];
        
        getPackage(nextID, devices["IRremote"], buttonValue);
    };
    
    /**
     * @brief   read ir receiver button value
     */
    ext.getIRremoteValue = function(nextID) {
        getPackage(nextID, devices["IRremote"]);
    };
    
    /**
     * @brief   read ir receiver button, counter
     *
     * @param   buttonValue up:12, down:14, left:15, right: 13, F1, F2, F3, F4, F5, F6
     * @param   count       감지횟수
     * @param   time        감지시간
     */
    ext.getIRremoteCount = function(nextID, buttonValue, count, time) {
        if (typeof buttonValue == "string") buttonValue = irButtonValues[buttonValue];
        
        getPackage(nextID, devices["IRremote"], buttonValue, count, time);
    };
    
    /**
     * @brief   read start button pressed
     *
     */
    ext.getStartButton = function(nextID) {
        getPackage(nextID, 19);
    };
    
    /**
     * @brief   read potentiometer
     *
     * @param   port        analog input ports (port 5-8)
     */
    ext.getPotentiometer = function(nextID, port) {
        if (typeof port == "string") port = ports[port];
        getPackage(nextID, devices["Potentiometer"], port);
    };
    
    /**
     * @brief   사용자 input 감지/미감지
     *
     * @param   port        input ports (port 1-8)
     * @param   senseValue  감지/미감지
     * @param   op          operator
     * @param   threshold   감지기준
     */
    ext.runCustomInput = function(nextID, port, senseValue, op, threshold) {
        if (typeof port == "string") port = ports[port];
        if (typeof senseValue == "string") senseValue = states[senseValue];
        if (typeof op == "string") op = opValues[op];
        
        getPackage(nextID, devices["Custom"], port, senseValue, op, short2array(threshold));
    };

    /*
     * @brief   DC motor Driven
     *
     * @param   port    mortor port
     * @param   speed   mortor speed
     */
    ext.runMotor = function(port, speed) {
        if (typeof port == "string") port = ports[port];
        
        // seq, direction, speed, degree, time
        runPackage(devices["Motor"], port, short2array(speed));
    };
    
    /*
     * @brief   servo motor driven
     *
     * @param   port    mortor port
     * @param   angle   angle
     * @param   speed   mortor speed
     */
    ext.runServoMotor = function(port, angle, speed) {
        if (typeof port == "string") port = ports[port];
        
        runPackage(devices["Servo"], port, short2array(angle), speed);
    };
    
    /**
     * @brief   LED
     *
     * @param   port    ouput port
     * @param   onoff   on/off
     */
    ext.ledOn = function(port, onoff) {
        if (typeof port == "string") port = ports[port];
        if (typeof onoff == "string") onoff = onOffValues[onoff];
        
        // seq, direction, speed, degree, time
        runPackage(devices["LED"], port, onoff);
    };
    
    /**
     * @brief   스피커 연주
     *
     * @param   port        output port (port 9-16)
     * @param   duration    tone (C2 ~ B8)
     * @param   frequency   beat ms (1/2, 1/4, 1/8, whole, Double, Zero)
     */
    ext.runSpeaker = function(port, tone, beat) {
        if (typeof port == "string") port = ports[port];
        if (typeof tone == "string") tone = tones[tone];
        if (typeof beat == "string") beat = beats[beat];
        
        runPackage(devices["Speaker"], port, short2array(tone), short2array(beat));
    };
    
    /**
     * @brief   버저 연주
     *
     * @param   port        output port (port 9-16)
     * @param   duration    time (ms)
     * @param   frequency   Hz
     */
    ext.playBuzzer = function(port, duration, frequency) {
        if (typeof port == "string") port = ports[port];
        
        runPackage(devices["Buzzer"], port, short2array(duration), short2array(frequency));
    };
    
    /**
     * @brief   buzzer on/off
     *
     * @param   port        output port (port 9-16)
     * @param   onoff       On/Off
     */
    ext.runBuzzer = function(port, onoff) {
        if (typeof port == "string") port = ports[port];
        if (typeof onoff == "string") onoff = onOffValues[onoff];
        
        runPackage(devices["Buzzer"], port, onoff);
    };
     
     /**
     * @brief   custom output on/off
     *
     * @param   port        output port (port 9-16)
     * @param   onoff       On/Off
     */
    ext.runCustomOutput = function(port, onoff) {
        if (typeof port == "string") port = ports[port];
        if (typeof onoff == "string") onoff = onOffValues[onoff];
        
        runPackage(devices["Custom"], port, onoff);
    };

    /**
    * @brief custom output pwm
    */
    ext.runCustomPWM = function(port, pwm) {
        if (typeof port == "string") port = ports[port];

        runPackage(devices["CustomPWM"], port, pwm);
    };
    
    // common function
    /**
     * @brief 모듈 실행
     */
    function runPackage() {
        var bytes = [0xff, 0x55, 0, 0, 2];

        for (var i=0; i<arguments.length; i++) {
            if (arguments[i].constructor == "[class Array]") {
                bytes = bytes.concat(arguments[i]);
            } 
            else {
                bytes.push(arguments[i]);
            }
        }//for

        bytes[2] = bytes.length-3;  // data length
        
        // 장치에 ArrayBuffer data 전송
        device.send(bytes);
    }//function
    
    /**
     * @brief   센서값 읽기
     * 
     */
    function getPackage() {
        var nextID = arguments[0];
        var len = arguments.length;
        
        var bytes = [0xff, 0x55];
        bytes.push(len+1);
        bytes.push(0);
        bytes.push(1);

        for (var i=1; i<len; i++) {
            // 2byte 
            if (arguments[i].constructor == "[class Array]") {
                bytes = bytes.concat(arguments[i]);
            } 
            // 1byte
            else {
                bytes.push(arguments[i]);
            }
        }//for
        
        bytes[2] = bytes.length-3;  // data length

        device.send(bytes);
    }//function getPackage

    // 수신 데이터 처리
    var _isParseStart = false;
    var _isParseStartIndex = 0;

    function processData(bytes) {
        var len=bytes.length;   // ArrayBuffer 데이터수
        if(_rxBuf.length > 30) _rxBuf=[];

        for (var index=0; index<len; index++) {
            var c= bytes[index];
            _rxBuf.push(c);

            if (_rxBuf.length >= 2) {
                if (_rxBuf[_rxBuf.length-1]==0x55 && _rxBuf[_rxBuf.length-2]==0xff) {
                    _isParseStart = true;
                    _isParseStartIndex = _rxBuf.length-2;
                }//if

                if (_rxBuf[_rxBuf.length-1]==0xa && _rxBuf[_rxBuf.length-2]==0xd && _isParseStart) {
                    _isParseStart = false;

                    var position = _isParseStartIndex+2;
                    var extId = _rxBuf[position];
                    position++;
                    var type = _rxBuf[position];
                    position++;

                    //1 byte, 2 float, 3 short, 4 len+string, 5 double
                    var value;
                    switch (type) {
                        case 1:
                            value = _rxBuf[position];
                            position++;
                            break;
                        case 2:
                            value = readFloat(_rxBuf, position);
                            position += 4;
                            if (value<-255 || value>1023) value=0;
                            break;
                        case 3:
                            value = readShort(_rxBuf, position);
                            position+=2;
                            break;
                        case 4:
                            var l = _rxBuf[position];
                            position++;
                            value = readString(_rxBuf, position, l);
                            break;
                        case 5:
                            value = readDouble(_rxBuf, position);
                            position +=4;
                            break;
                    }//switch

                    if (type <= 5) {
                        if (values[extId] != undefined) {
                            responseValue(extId, values[extId](value, extId));
                        } 
                        else {
                            responseValue(extId, value);
                        }

                        values[extId] = null;
                    }//if

                    _rxBuf=[];
                }//if
            }//if
        }//for
    }//function

    function readFloat(arr, position) {
        var f = [arr[position], arr[position+1], arr[position+2], arr[position+3]];
        return parseFloat(f);
    }//function

    function readShort(arr, position) {
        var s = [arr[postion], arr[postion+1]];
        return parseShort(s);
    }//furnction

    function readDouble(arr, position) {
        return readFloat(arr, position);
    }//function

    function readString(arr, position, len) {
        var value = "";
        for (var ii=0; ii<len; ii++) {
            value += String.fromCharCode(_rxBuf[ii+position]);
        }//for

        return value;
    }//function

    // Extension API interactions
    var potentialDevices = [];

    function tryNextDevice() {
        device = potentialDevices.shift();
        if (device) {
            // device.open()
            // options
            //- stopBits : The number of stop bits per character, default:1 (0: 1bit, 1:1.5bit, 2:2bit) 
            //- bitRate : Up to The bit (or baud) rate at which to communicate. default: 9600
            //- ctsFlowControl: The type of flow control to use. default:1 (0:none, 1:software, 2:hardware) 
            //- bufferSize: The maximum amount of data that can be received at a time. default: 4096 (~8192)
            //- dataBits: The number of data bits per character. default: 8 (5,6,7,8)
            //- parityBit: Whether and how to use the parity bit in each character. default:0 (0:none, 1:odd, 2:even)
            device.open({stopBits: 0, bitRate: 115200, ctsFlowControl: 0}, deviceOpened);
        }//if
    }//function

    var watchdog = null;
    function deviceOpened(dev) {
        if (!dev) {
            //opening the port failed
            tryNextDevice();
            return;
        }//if

        // 수신된 데이터를 처리하는 함수 등록
        device.set_receive_handler('MRTduino', processData); 
    }//function

    // 장치 연결 - serial
    ext._deviceConnected = function(dev) {
        potentialDevices.push(dev);

        if(!device) tryNextDevice();
    }//function

    // device connection stop
    ext._deviceRemoved = function(dev) {
        if(device != dev) return;
        device = null;
    }

    // extension 종료
    ext._shutdown = function() {
        if(device) device.close();
        device = null;
    }//function

    // 하드웨어 장치와 통신이 되었는지 여부
    ext._getStatus = function() {
        // status :  0 (red, error), 1 (yellow, not ready), 2 (green, ready)
        if(!device) return {status: 1, msg: 'MRTduino not connected'};
        if(watchdog) return {status: 1, msg: 'Probing for MRTduino'};

        return {status: 2, msg: 'MRTduino connected'};
    }

    // Register the Extension 
    var descriptor = {};

    // ScrachExtension.register()
    // @param Example Name
    // @param descriptor_object
    // @param ext_instance
    // @param hardware_info or serial_info (optional)
    // 
    // hardware_info = {type: 'hid', vendor: 0x0694, product: 0x0003}
    // - vendor : 16진수 (0x0000)
    // - product : 16진수 (0x0000 , 제품ID
    // serial_info = {type: 'serial'}
    ScratchExtensions.register("MRTduino", descriptor, ext, {type: 'serial'});
})({});